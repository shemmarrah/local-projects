<?php 
get_header();
	
?>

<div class="beauty_container">
			<div class="sf_fashion">
				
				 <ul>
				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/beauty-lauren">
				 	<?php echo get_the_post_thumbnail(635); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(635);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>
				 	<li>
				 	<a href="">
				 		<?php echo get_the_post_thumbnail(140); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(140);
				 				echo $maincontent->post_title;?></h3>
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					</a> 	
				 	</li>
				 	
					
					<!-- <li>
				 	<a href="">
				 		<?php //echo get_the_post_thumbnail(145); ?>
					 	<div class="sf_fashion_content">
					 		<h3><?php $maincontent //= get_post(145);
				 			//echo $maincontent->post_title;?></h3>
				 			<p><?php //echo $maincontent->post_content; ?></p>
					 	</div>
					</a>
				 	</li> -->

				 </ul>
			</div>
					
		</div>


<?php

get_footer();
 ?>