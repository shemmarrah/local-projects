<form target="_blank" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="image" src="<?php bloginfo('template_url'); ?>/forms/images/donate_button.png" border="0" name="submit" alt="Donate">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="Z52AFL278VSAG">

<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">

</form>