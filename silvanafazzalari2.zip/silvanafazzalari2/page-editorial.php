<?php 
get_header();
	
?>
	

<div class="editorial_container">
			<div class="sf_fashion">
				
				 <ul>
				 <li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-letulle">
				 	<?php echo get_the_post_thumbnail(544); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(544);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>


				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-clouddress">
				 	<?php echo get_the_post_thumbnail(546); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(546);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>

				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-si">
				 	<?php echo get_the_post_thumbnail(548); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(548);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>


				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-rapture">
				 	<?php echo get_the_post_thumbnail(550); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(550);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>
					
					<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-1957-2">
				 	<?php echo get_the_post_thumbnail(552); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(552);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>

					<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-corsadinotte">
				 	<?php echo get_the_post_thumbnail(554); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(554);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>

				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-girls">
				 	<?php echo get_the_post_thumbnail(556); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(556);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>


				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-bluemoon">
				 	<?php echo get_the_post_thumbnail(558); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(558);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>

				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-sloelenitivo">
				 	<?php echo get_the_post_thumbnail(560); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(560);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>

				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-ka">
				 	<?php echo get_the_post_thumbnail(562); ?>
					 	<div class="sf_fashion_content">
					 				<h3><?php $maincontent = get_post(562);
				 				echo $maincontent->post_title;?></h3>	
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					 </a>
				 	</li>
				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-duel-impasse">
				 		<?php echo get_the_post_thumbnail(564); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(564);
				 				echo $maincontent->post_title;?></h3>
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					</a> 	
				 	</li>
				 	<li>



				 	<a href="<?php bloginfo('template_url') ?>/editorial-intimate-life">
				 		<?php echo get_the_post_thumbnail(566); ?>
					 	<div class="sf_fashion_content">
					 		<h3><?php $maincontent = get_post(566);
				 			echo $maincontent->post_title;?></h3>
				 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					</a>
				 	</li>
				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-voyager">
				 		<?php echo get_the_post_thumbnail(568); ?>
					 	<div class="sf_fashion_content">
					 		<h3><?php $maincontent = get_post(568);
				 			echo $maincontent->post_title;?></h3>
				 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					</a>
				 	</li>


				 	<li>
				 	<a href="<?php bloginfo('template_url') ?>/editorial-lana">
				 		<?php echo get_the_post_thumbnail(570); ?>
					 	<div class="sf_fashion_content">
					 			<h3><?php $maincontent = get_post(570);
				 				echo $maincontent->post_title;?></h3>
					 			<p><?php echo $maincontent->post_content; ?></p>
					 	</div>
					</a> 	
				 	</li>
				 	<li>

				 </ul>
			</div>
					
		</div>


<?php

get_footer();
 ?>