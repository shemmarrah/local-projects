<p>Prayer Service Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis ac eros libero. 
					Suspendisse potenti. Nam ornare mi vitae nisi interdum, non consectetur enim eleifend. 
					Vestibulum sit amet ultrices risus. Fusce ullamcorper porttitor ullamcorper. 
					Ut sed urna in ipsum facilisis condimentum a vitae lorem. Ut ac metus dolor. 
					Suspendisse potenti.</p>