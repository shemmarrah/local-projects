<?php 
get_header();
	
?>
<div class="sf-main">
		<div class="sf-main__tint"></div>
		<div class="sf-main__image">
		
			<div class="sf-main__crossfade">
			  <figure></figure>
			  <figure></figure>
			  <figure></figure>
			  <figure></figure>
			  <figure></figure>
			</div>
			
		</div>
	</div>

<div class="booooo" style="height: 130px; width: 100%; float: left; margin-top: 400px; text-align: center; color: #fff; text-transform: capitalize;">
	
	<h1>comming soon</h1>
</div>

<?php
get_footer();
 ?>