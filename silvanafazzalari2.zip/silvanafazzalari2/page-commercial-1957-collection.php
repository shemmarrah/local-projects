<?php 
get_header();
	
?>
	
	<div class="commercial_container-gallery">

		<div class="row">
	    	<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>


			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>



			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
			<div class="col-md-6 col-lg-4">
			<?php echo get_the_post_thumbnail(520); ?>
			</div>
		</div>	
	</div>

<?php
get_footer();
 ?>